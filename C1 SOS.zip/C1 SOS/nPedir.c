#include "nSystem.h"
#include "nSysimp.h"

int cnt[2];
// cnt[cat] es el n° de threads de
// categoría cat en espera.
int ocup; // -1: libre
// 0 o 1: ocupado por thread de cat 0 o 1
Queue unos;
Queue ceros;

void pedirInit(){
	cnt[0]= 0;
	cnt[1]= 0;
	ocup= -1;
	unos= MakeQueue();
	ceros= MakeQueue();
}

void nPedir(int cat) {
	START_CRITICAL();
	if (ocup==-1){
		ocup= cat;
        END_CRITICAL();
	}
	
	else {
        END_CRITICAL();
		nTask this_task = current_task;
		cnt[cat]++;
		this_task->status= WAIT_PEDIR;
		if(cat){
			PutTask(unos, this_task);
		}
		else{
			PutTask(ceros, this_task);
		}
		ResumeNextReadyTask(); // cambio de contexto
	}
}

void nDevolver() {
	if (cnt[!ocup]>0) {
		cnt[!ocup]--;
		ocup= !ocup;
		if(ocup){ //si ocup pasa a ser 1, se saca una task de la queue de unos y se deja READY
			nTask siguiente= GetTask(unos);
			siguiente->status= READY;
			PutTask(ready_queue , siguiente);
		}
		else{
			nTask siguiente= GetTask(ceros);
			siguiente->status= READY;
			PutTask(ready_queue , siguiente);
		}
		nTask this_task = current_task;
		PushTask(ready_queue , this_task);
		ResumeNextReadyTask(); // cambio de contexto
	}  
	else if (cnt[ocup]>0) {
		cnt[ocup]--;
		if(ocup){ //si ocup pasa a ser 1, se saca una task de la queue de unos y se deja READY
			nTask siguiente= GetTask(unos);
			siguiente->status= READY;
			PutTask(ready_queue , siguiente);
		}
		else{
			nTask siguiente= GetTask(ceros);
			siguiente->status= READY;
			PutTask(ready_queue , siguiente);
		}
		nTask this_task = current_task;
		PushTask(ready_queue , this_task);
		ResumeNextReadyTask(); // cambio de contexto
	}  
	else    
		ocup= -1;
}
